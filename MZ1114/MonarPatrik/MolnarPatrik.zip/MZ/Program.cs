﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MZ
{
    class Program
    {
        static void Main(string[] args)
        {
            //Feladatok.ElemekKiir();

            Feladatok.FeladatokVegrahajtasa();

            Console.ReadLine();

        }
    }
}
